<?php
if(estConnecteVisiteur()){
	include(VIEWSPATH."v_sommaireVisiteur.php");
	$idCollaborateur = $_SESSION['idVisiteur'];
}
else {
	if(estConnecteDelegue()){
		include(VIEWSPATH."v_sommaireDelegue.php");
		$idCollaborateur = $_SESSION['idDelegue'];
	}
	else{
		ajouterErreur("Erreur de connexion");
		include(VIEWSPATH."v_erreurs.php");
	}
}

$action = trim(htmlentities($_REQUEST['action']));
switch($action){
	case 'choisirMedicament':{
		$medicaments = $pdo->getLesMedicaments();
		include(VIEWSPATH."v_listeMedicament.php");
		break;
	}
	case 'voirMedicament':{
		$depotlegal = trim(htmlentities($_REQUEST['lstMedicament']));
		$medicament = $pdo->getUnMedicament($depotlegal);
		include(VIEWSPATH."v_consultMedicament.php");
		break;
	}
	default:{
		$medicaments = $pdo->getLesMedicaments();
		include(VIEWSPATH."v_listeMedicament.php");
		break;
	}
}
?>
