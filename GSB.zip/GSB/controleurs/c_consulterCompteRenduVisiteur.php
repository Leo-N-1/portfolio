<?php
if(estConnecteResponsable()){
	include(VIEWSPATH."v_sommaireResponsable.php");
	$idCollaborateur = $_SESSION['idResponsable'];
}
else{
	ajouterErreur("Erreur de connexion");
	include(VIEWSPATH."v_erreurs.php");
}

$action = trim(htmlentities($_REQUEST['action']));
switch($action){
	case 'choisirVisiteur':{
		$visiteurs = $pdo->getLesVisiteurs();
		include(VIEWSPATH."v_choisirVisiteur.php");
		break;
	}
	case 'voirCompteRenduVisiteur':{
		$matriculeVisiteur = trim(htmlentities($_REQUEST['lstVisiteur']));
		$compteRendus = $pdo->getCompteRenduParVisiteur($matriculeVisiteur);
		include(VIEWSPATH."v_listeCompteRenduVisiteur.php");
		break;
	}
	default:{
		$visiteurs = $pdo->getLesVisiteurs();
		include(VIEWSPATH."v_choisirVisiteur.php");
		break;
	}
}
?>
