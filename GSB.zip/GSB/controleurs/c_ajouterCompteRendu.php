<?php
if(estConnecteVisiteur()){
	include(VIEWSPATH."v_sommaireVisiteur.php");
	$idCollaborateur = $_SESSION['idVisiteur'];
}
else{
	if(estConnecteDelegue()){
		include(VIEWSPATH."v_sommaireDelegue.php");
		$idCollaborateur = $_SESSION['idDelegue'];
	}
	else{
		ajouterErreur("Erreur de connexion");
		include(VIEWSPATH."v_erreurs.php");
	}
}
$action = trim(htmlentities($_REQUEST['action']));
switch($action){
	case 'saisirCompteRendu':{
		$praticiens  = $pdo->getLesPraticiens();
		$motifs      = $pdo->getLesMotifs();
		$medicaments = $pdo->getLesMedicaments();
		include(VIEWSPATH."v_ajouterCompteRendu.php");
		break;
	}
	case 'validerCompteRendu':{
		$numRapport       = trim(htmlentities($_REQUEST['txtNumero']));
		$dateVisite       = trim(htmlentities($_REQUEST['txtDateVisite']));
		$numPraticien     = trim(htmlentities($_REQUEST['lstPraticien']));
		$confiance        = trim(htmlentities($_REQUEST['txtConfiance']));
		$remplacant       = isset($_REQUEST['chkRemplacant']) ? 1 : 0;
		$numRemplacant    = $remplacant ? trim(htmlentities($_REQUEST['lstRemplacant'])) : null;
		$motif            = trim(htmlentities($_REQUEST['lstMotif']));
		$autreMotif       = trim(htmlentities($_REQUEST['txtAutreMotif']));
		$bilan            = trim(htmlentities($_REQUEST['txtBilan']));
		$documentation    = isset($_REQUEST['chkDoc']) ? 1 : 0;
		$dateSaisie       = trim(htmlentities($_REQUEST['txtDateSaisie']));
		$saisieDefinitive = isset($_REQUEST['chkSaisie']) ? 1 : 0;

		if($numRapport == '' || $dateVisite == '' || $numPraticien == ''){
			ajouterErreur("Veuillez renseigner au minimum le numéro, la date de visite et le praticien");
		}
		if(nbErreurs() == 0){
			$pdo->ajouterCompteRendu($idCollaborateur, $numRapport, $numPraticien, $numRemplacant,
				$dateVisite, $dateSaisie, $bilan, $autreMotif, $motif, $documentation, $saisieDefinitive);

			// Produits présentés
			if(isset($_REQUEST['chkProduitPresente1']) && $_REQUEST['lstProduit1'] != ''){
				$pdo->ajouterProduitPresente($_REQUEST['lstProduit1'], $idCollaborateur, $numRapport);
			}
			if(isset($_REQUEST['chkProduitPresente2']) && $_REQUEST['lstProduit2'] != ''){
				$pdo->ajouterProduitPresente($_REQUEST['lstProduit2'], $idCollaborateur, $numRapport);
			}

			// Échantillons
			if(isset($_REQUEST['lstEchantillon']) && isset($_REQUEST['txtQte'])){
				$echantillons = $_REQUEST['lstEchantillon'];
				$quantites    = $_REQUEST['txtQte'];
				for($i = 0; $i < count($echantillons); $i++){
					if($echantillons[$i] != '' && $quantites[$i] != ''){
						$pdo->ajouterEchantillon($idCollaborateur, $numRapport, $echantillons[$i], $quantites[$i]);
					}
				}
			}
			include(VIEWSPATH."v_compteRenduValide.php");
		} else {
			include(VIEWSPATH."v_erreurs.php");
			$praticiens  = $pdo->getLesPraticiens();
			$motifs      = $pdo->getLesMotifs();
			$medicaments = $pdo->getLesMedicaments();
			include(VIEWSPATH."v_ajouterCompteRendu.php");
		}
		break;
	}
	default:{
		$praticiens  = $pdo->getLesPraticiens();
		$motifs      = $pdo->getLesMotifs();
		$medicaments = $pdo->getLesMedicaments();
		include(VIEWSPATH."v_ajouterCompteRendu.php");
		break;
	}
}
?>
