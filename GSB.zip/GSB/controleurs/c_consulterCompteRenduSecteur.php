<?php
if(estConnecteResponsable()){
	include(VIEWSPATH."v_sommaireResponsable.php");
	$idResponsable = $_SESSION['idResponsable'];
}
else{
	ajouterErreur("Erreur de connexion");
	include(VIEWSPATH."v_erreurs.php");
}
$action = trim(htmlentities($_REQUEST['action']));
switch($action){
	case 'voirCompteRenduSecteur':{
		$secteur = $pdo->getSecteurDuResponsable($idResponsable);
		$codeSecteur = $secteur['code'];
		$compteRendus = $pdo->getCompteRenduParSecteur($codeSecteur);
		include(VIEWSPATH."v_listeCompteRenduSecteur.php");
		break;
	}
	default:{
		$secteur = $pdo->getSecteurDuResponsable($idResponsable);
		$codeSecteur = $secteur['code'];
		$compteRendus = $pdo->getCompteRenduParSecteur($codeSecteur);
		include(VIEWSPATH."v_listeCompteRenduSecteur.php");
		break;
	}
}
?>
