<?php
if(estConnecteVisiteur()){
	include(VIEWSPATH."v_sommaireVisiteur.php");
	$idCollaborateur = $_SESSION['idVisiteur'];
}
else {
	if(estConnecteDelegue()){
		include(VIEWSPATH."v_sommaireDelegue.php");
		$idCollaborateur = $_SESSION['idDelegue'];
	}
	else{
		ajouterErreur("Erreur de connexion");
		include(VIEWSPATH."v_erreurs.php");
	}
}

$action = trim(htmlentities($_REQUEST['action']));
switch($action){
	case 'saisirPraticien':{
		$typesPraticien = $pdo->getLesTypesPraticien();
		include(VIEWSPATH."v_ajoutPraticien.php");
		break;
	}
	case 'validerPraticien':{
		$num       = trim(htmlentities($_REQUEST['txtNumero']));
		$nom       = trim(htmlentities($_REQUEST['txtNom']));
		$prenom    = trim(htmlentities($_REQUEST['txtPrenom']));
		$adresse   = trim(htmlentities($_REQUEST['txtAdresse']));
		$cp        = trim(htmlentities($_REQUEST['txtCp']));
		$ville     = trim(htmlentities($_REQUEST['txtVille']));
		$notoriete = trim(htmlentities($_REQUEST['txtNotoriete']));
		$confiance = trim(htmlentities($_REQUEST['txtConfiance']));
		$type      = trim(htmlentities($_REQUEST['lstType']));

		if($num == '' || $nom == '' || $prenom == ''){
			ajouterErreur("Veuillez renseigner au minimum le numéro, le nom et le prénom");
		}
		if(nbErreurs() == 0){
			$pdo->ajouterPraticien($num,$nom,$prenom,$adresse,$cp,$ville,$notoriete,$confiance,$type);
			include(VIEWSPATH."v_praticienValide.php");
		} else {
			include(VIEWSPATH."v_erreurs.php");
			$typesPraticien = $pdo->getLesTypesPraticien();
			include(VIEWSPATH."v_ajoutPraticien.php");
		}
		break;
	}
	default:{
		$typesPraticien = $pdo->getLesTypesPraticien();
		include(VIEWSPATH."v_ajoutPraticien.php");
		break;
	}
}
?>
