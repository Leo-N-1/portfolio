<?php
if(estConnecteVisiteur()){
	include(VIEWSPATH."v_sommaireVisiteur.php");
	$idCollaborateur = $_SESSION['idVisiteur'];
}
else {
	if(estConnecteDelegue()){
		include(VIEWSPATH."v_sommaireDelegue.php");
		$idCollaborateur = $_SESSION['idDelegue'];
	}
	else{
		ajouterErreur("Erreur de connexion");
		include(VIEWSPATH."v_erreurs.php");
	}
}

$action = trim(htmlentities($_REQUEST['action']));
switch($action){
	case 'choisirPraticien':{
		$praticiens = $pdo->getLesPraticiens();
		include(VIEWSPATH."v_listePraticien.php");
		break;
	}
	case 'voirPraticien':{
		$num = trim(htmlentities($_REQUEST['lstPraticien']));
		$praticien = $pdo->getUnPraticien($num);
		include(VIEWSPATH."v_consultPraticien.php");
		break;
	}
	default:{
		$praticiens = $pdo->getLesPraticiens();
		include(VIEWSPATH."v_listePraticien.php");
		break;
	}
}
?>
