<?php
if(estConnecteVisiteur()){
	include(VIEWSPATH."v_sommaireVisiteur.php");
	$idVisiteur = $_SESSION['idVisiteur'];
}
else{
	if(estConnecteDelegue()){
		include(VIEWSPATH."v_sommaireDelegue.php");
		$idDelegue = $_SESSION['idDelegue'];
	}
	else{
		if(estConnecteResponsable()){
			include(VIEWSPATH."v_sommaireResponsable.php");
			$idResponsable = $_SESSION['idResponsable'];
		}
		else{
			ajouterErreur("Erreur de connexion");
			include(VIEWSPATH."v_erreurs.php");
		}
	}
}
$action = trim(htmlentities($_REQUEST['action']));
switch($action){
	case 'choisirPeriode':{
		include(VIEWSPATH."v_consulterPeriode.php");
		break;
	}
	case 'voirCompteRenduPeriode':{
		$dateDebut  = trim(htmlentities($_REQUEST['txtDateDebut']));
		$dateFin    = trim(htmlentities($_REQUEST['txtDateFin']));
		// Si visiteur, on filtre sur lui-même
		$matricule = null;
		if(isset($idVisiteur)) $matricule = $idVisiteur;
		if(isset($idDelegue))  $matricule = $idDelegue;
		$compteRendus = $pdo->getCompteRenduParPeriode($dateDebut, $dateFin, $matricule);
		include(VIEWSPATH."v_listeCompteRenduPeriode.php");
		break;
	}
	default:{
		include(VIEWSPATH."v_consulterPeriode.php");
		break;
	}
}
?>
