<?php
if(!isset($_REQUEST['action'])){
	$_REQUEST['action'] = 'demandeConnexion';
}
$action = trim(htmlentities($_REQUEST['action']));
switch($action){
	case 'demandeConnexion':{
		include(VIEWSPATH."v_connexion.php");
		break;
	}
	case 'valideConnexion':{
		$login = trim(htmlentities($_REQUEST['login']));
		$mdp = trim(htmlentities($_REQUEST['mdp']));
		$collaborateur = $pdo->getIdCollaborateur($login,$mdp);
		if(!is_array($collaborateur)){
			ajouterErreur("Login ou mot de passe incorrect");
			include(VIEWSPATH."v_erreurs.php");
			include(VIEWSPATH."v_connexion.php");
		}
		else{
			$matricule = $collaborateur['matricule'];
			if ($pdo->estResponsable($matricule)){
				$responsable = $pdo->getInfosResponsable($matricule);
				$nom = $responsable['nom'];
				$prenom = $responsable['prenom'];
				connecterResponsable($matricule,$nom,$prenom);
				include(VIEWSPATH."v_sommaireResponsable.php");
				include(VIEWSPATH."v_accueil.php");
			}
			else{
				if ($pdo->estDelegue($matricule)){
					$delegue = $pdo->getInfosDelegue($matricule);
					$nom = $delegue['nom'];
					$prenom = $delegue['prenom'];
					connecterDelegue($matricule,$nom,$prenom);
					include(VIEWSPATH."v_sommaireDelegue.php");
					include(VIEWSPATH."v_accueil.php");
				}
				else{
					$visiteur = $pdo->getInfosCollaborateur($matricule);
					$nom = $visiteur['nom'];
					$prenom = $visiteur['prenom'];
					connecterVisiteur($matricule,$nom,$prenom);
					include(VIEWSPATH."v_sommaireVisiteur.php");
					include(VIEWSPATH."v_accueil.php");
				}
			}
		}
		break;
	}
	case 'deconnexion':{
		deconnecter();
		include(VIEWSPATH."v_connexion.php");
		break;
	}
	default :{
		include(VIEWSPATH."v_connexion.php");
		break;
	}
}
?>
