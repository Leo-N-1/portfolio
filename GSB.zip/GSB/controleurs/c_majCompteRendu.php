<?php
if(estConnecteVisiteur()){
	include(VIEWSPATH."v_sommaireVisiteur.php");
	$idCollaborateur = $_SESSION['idVisiteur'];
}
else {
	if(estConnecteDelegue()){
		include(VIEWSPATH."v_sommaireDelegue.php");
		$idCollaborateur = $_SESSION['idDelegue'];
	}
	else{
		ajouterErreur("Erreur de connexion");
		include(VIEWSPATH."v_erreurs.php");
	}
}

$action = trim(htmlentities($_REQUEST['action']));
switch($action){
	case 'choisirCompteRendu':{
		$compteRendus = $pdo->getLesCompteRenduDuVisiteur($idCollaborateur);
		include(VIEWSPATH."v_listeCompteRendu.php");
		break;
	}
	case 'modifierCompteRendu':{
		$numRapport  = trim(htmlentities($_REQUEST['lstRapport']));
		$compteRendu = $pdo->getUnCompteRendu($numRapport);
		$praticiens  = $pdo->getLesPraticiens();
		$motifs      = $pdo->getLesMotifs();
		$medicaments = $pdo->getLesMedicaments();
		include(VIEWSPATH."v_majCompteRendu.php");
		break;
	}
	case 'validerModification':{
		$numRapport       = trim(htmlentities($_REQUEST['txtNumero']));
		$dateVisite       = trim(htmlentities($_REQUEST['txtDateVisite']));
		$numPraticien     = trim(htmlentities($_REQUEST['lstPraticien']));
		$numRemplacant    = isset($_REQUEST['lstRemplacant']) ? trim(htmlentities($_REQUEST['lstRemplacant'])) : null;
		$motif            = trim(htmlentities($_REQUEST['lstMotif']));
		$autreMotif       = trim(htmlentities($_REQUEST['txtAutreMotif']));
		$bilan            = trim(htmlentities($_REQUEST['txtBilan']));
		$documentation    = isset($_REQUEST['chkDoc']) ? 1 : 0;
		$dateSaisie       = trim(htmlentities($_REQUEST['txtDateSaisie']));
		$saisieDefinitive = isset($_REQUEST['chkSaisie']) ? 1 : 0;

		if($numRapport == '' || $dateVisite == ''){
			ajouterErreur("Veuillez renseigner le numéro et la date de visite");
		}
		if(nbErreurs() == 0){
			$pdo->modifierCompteRendu($numRapport, $numPraticien, $numRemplacant,
				$dateVisite, $dateSaisie, $bilan, $autreMotif, $motif, $documentation, $saisieDefinitive);
			include(VIEWSPATH."v_compteRenduValide.php");
		} else {
			include(VIEWSPATH."v_erreurs.php");
			$compteRendu = $pdo->getUnCompteRendu($numRapport);
			$praticiens  = $pdo->getLesPraticiens();
			$motifs      = $pdo->getLesMotifs();
			$medicaments = $pdo->getLesMedicaments();
			include(VIEWSPATH."v_majCompteRendu.php");
		}
		break;
	}
	default:{
		$compteRendus = $pdo->getLesCompteRenduDuVisiteur($idCollaborateur);
		include(VIEWSPATH."v_listeCompteRendu.php");
		break;
	}
}
?>
