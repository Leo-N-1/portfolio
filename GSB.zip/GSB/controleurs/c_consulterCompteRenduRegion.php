<?php
if(estConnecteDelegue()){
	include(VIEWSPATH."v_sommaireDelegue.php");
	$idDelegue = $_SESSION['idDelegue'];
}
else{
	if(estConnecteResponsable()){
		include(VIEWSPATH."v_sommaireResponsable.php");
		$idResponsable = $_SESSION['idResponsable'];
	}
	else{
		ajouterErreur("Erreur de connexion");
		include(VIEWSPATH."v_erreurs.php");
	}
}
$action = trim(htmlentities($_REQUEST['action']));
switch($action){
	case 'choisirRegion':{
		$regions = $pdo->getLesRegions();
		include(VIEWSPATH."v_choisirRegion.php");
		break;
	}
	case 'voirCompteRenduRegion':{
		// Si délégué, on utilise sa propre région
		if(isset($idDelegue)){
			$regionDelegue = $pdo->getRegionDuDelegue($idDelegue);
			$codeRegion = $regionDelegue['code'];
		} else {
			$codeRegion = trim(htmlentities($_REQUEST['lstRegion']));
		}
		$compteRendus = $pdo->getCompteRenduParRegion($codeRegion);
		include(VIEWSPATH."v_listeCompteRenduRegion.php");
		break;
	}
	default:{
		// Délégué : va directement sur sa région
		if(isset($idDelegue)){
			$regionDelegue = $pdo->getRegionDuDelegue($idDelegue);
			$codeRegion = $regionDelegue['code'];
			$compteRendus = $pdo->getCompteRenduParRegion($codeRegion);
			include(VIEWSPATH."v_listeCompteRenduRegion.php");
		} else {
			$regions = $pdo->getLesRegions();
			include(VIEWSPATH."v_choisirRegion.php");
		}
		break;
	}
}
?>
