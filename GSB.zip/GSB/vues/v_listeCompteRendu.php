 <div id="contenu">
      <h2>Modifier un compte rendu</h2>
      <form action="index.php?uc=majCompteRendu&action=modifierCompteRendu" method="post">
      <div class="corpsForm">
  
	  <p>
		<label for="lstRapport">Choisir le rapport</label>
		<select name='lstRapport' id='lstRapport'>
            <?php
                foreach($compteRendus as $cr){
                    echo "<option value='".$cr['num']."'>N°".$cr['num']." - ".$cr['dateVisite']." - ".$cr['nomPraticien']." ".$cr['prenomPraticien']."</option>";
                }
            ?>
		</select>
	  </p>  

       <p class="titre" /><label class="titre">&nbsp;</label>
		<input class="zone" type="submit" value="Valider" size="20" />
        <input id="annuler" type="reset" value="Effacer" size="20" /> 
		</p> 
	  </div>
      </form>
</div>
