<div id="contenu">
    <h2>Choisir une région</h2>
    <form action="index.php?uc=consulterCompteRenduRegion&action=voirCompteRenduRegion" method="post">
    <div class="corpsForm">
        <p>
            <label for="lstRegion">REGION : </label>
            <select id="lstRegion" name="lstRegion">
                <?php
                    foreach($regions as $region){
                        echo "<option value='".$region['code']."'>".$region['nom']."</option>";
                    }
                ?>
            </select>
        </p>
        <p>
            <input class="zone" type="submit" value="Valider" size="20" />
        </p>
    </div>
    </form>
</div>
