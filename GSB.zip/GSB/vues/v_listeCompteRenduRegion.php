<div id="contenu">
    <h2>Compte-rendus de la région</h2>
    <table border="1" cellpadding="5">
        <tr>
            <th>N°</th>
            <th>Date visite</th>
            <th>Visiteur</th>
            <th>Praticien</th>
            <th>Bilan</th>
        </tr>
        <?php
            if(count($compteRendus) == 0){
                echo "<tr><td colspan='5'>Aucun compte-rendu pour cette région</td></tr>";
            }
            foreach($compteRendus as $cr){
                echo "<tr>";
                echo "<td>".$cr['num']."</td>";
                echo "<td>".$cr['dateVisite']."</td>";
                echo "<td>".$cr['nomVisiteur']." ".$cr['prenomVisiteur']."</td>";
                echo "<td>".$cr['nomPraticien']." ".$cr['prenomPraticien']."</td>";
                echo "<td>".$cr['bilan']."</td>";
                echo "</tr>";
            }
        ?>
    </table>
</div>
