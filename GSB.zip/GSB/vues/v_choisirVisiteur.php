<div id="contenu">
    <h2>Choisir un visiteur</h2>
    <form action="index.php?uc=consulterCompteRenduVisiteur&action=voirCompteRenduVisiteur" method="post">
    <div class="corpsForm">
        <p>
            <label for="lstVisiteur">VISITEUR : </label>
            <select id="lstVisiteur" name="lstVisiteur">
                <?php
                    foreach($visiteurs as $visiteur){
                        echo "<option value='".$visiteur['matricule']."'>".$visiteur['nom']." ".$visiteur['prenom']."</option>";
                    }
                ?>
            </select>
        </p>
        <p>
            <input class="zone" type="submit" value="Valider" size="20" />
        </p>
    </div>
    </form>
</div>
