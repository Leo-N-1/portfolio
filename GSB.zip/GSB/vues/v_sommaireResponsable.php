    <!-- Division pour le sommaire -->
    <div id="menuGauche">
     <div id="infosUtil">
    
        <h2>
			<?php  
				echo $_SESSION['prenom']."  ".$_SESSION['nom'];
			?>    
		</h2>
         <h3>Responsable</h3>    
      </div>  
        <ul id="menuList">
			<li class="smenu">
              <a href="index.php?uc=consulterCompteRenduPeriode&action=choisirPeriode" title="Consultation des compte-rendus par période">Compte-rendus d'une période</a>
           </li>
			<li class="smenu">
              <a href="index.php?uc=consulterCompteRenduSecteur&action=voirCompteRenduSecteur" title="Consultation des compte-rendus du secteur">Compte-rendus du secteur</a>
           </li>
			<li class="smenu">
              <a href="index.php?uc=consulterCompteRenduVisiteur&action=choisirVisiteur" title="Consultation des compte-rendus d'un visiteur">Compte-rendus d'un visiteur</a>
           </li>
			<li class="smenu">
              <a href="index.php?uc=connexion&action=deconnexion" title="Se déconnecter">Déconnexion</a>
           </li>
        </ul>
        
    </div>
