<div id="contenu">
    <h2>Compte-rendus d'une période</h2>
    <form action="index.php?uc=consulterCompteRenduPeriode&action=voirCompteRenduPeriode" method="post">
    <div class="corpsForm">
        <p>
            <label for="txtDateDebut">DATE DEBUT : </label>
            <input type="date" size="10" name="txtDateDebut" id="txtDateDebut" />
        </p>
        <p>
            <label for="txtDateFin">DATE FIN : </label>
            <input type="date" size="10" name="txtDateFin" id="txtDateFin" />
        </p>
        <p>
            <input class="zone" type="submit" value="Valider" size="20" />
            <input id="annuler" type="reset" value="Effacer" size="20" />
        </p>
    </div>
    </form>
</div>
