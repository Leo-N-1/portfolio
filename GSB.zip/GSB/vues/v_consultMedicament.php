      <div class="corpsForm">
		<p>
			<label for="txtDepotLegal">DEPOT LEGAL : </label>
			<input type="text" size="15" id="txtDepotLegal" name="txtDepotLegal" readonly value="<?php echo $medicament['depotlegal']; ?>"  />
		</p>
		<p>
			<label for="txtNomCommercial">NOM COMMERCIAL : </label>
			<input type="text" size="25" id="txtNomCommercial" name="txtNomCommercial" readonly value="<?php echo $medicament['nomcommercial']; ?>" />
		</p>
		<p>
			<label for="txtFamille">FAMILLE : </label>
			<textarea rows="5" cols="50" id="txtFamille" name="txtFamille"><?php echo $medicament['famille']; ?></textarea>
		</p>
		<p>
			<label for="txtComposition">COMPOSITION : </label>
			<textarea rows="5" cols="50" id="txtComposition" name="txtComposition"><?php echo $medicament['composition']; ?></textarea>
		</p>
		<p>
			<label for="txtEffet">EFFETS : </label>
			<textarea rows="5" cols="50" id="txtEffet" name="txtEffet"><?php echo $medicament['effets']; ?></textarea>
		</p>
		<p>
			<label for="txtContreIndic">CONTRE INDICATIONS : </label>
			<textarea rows="5" cols="50" id="txtContreIndic" name="txtContreIndic"><?php echo $medicament['contreindic']; ?></textarea>
		</p>
	  </div>
