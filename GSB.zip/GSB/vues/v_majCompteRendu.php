<div id="contenu">
    <h2>Modifier un compte rendu</h2>
 	<form method="POST" action="index.php?uc=majCompteRendu&action=validerModification">
			<p>
				<label for="txtNumero">NUMERO : </label>
				<input type="text" size="10" id="txtNumero" name="txtNumero" readonly value="<?php echo $compteRendu['num']; ?>" />
			</p>
			<p>
				<label for="txtDateVisite">DATE VISITE : </label>			
				<input type="text" size="10" id="txtDateVisite" name="txtDateVisite" value="<?php echo $compteRendu['dateVisite']; ?>" />
			</p>
			<p>
				<label for="lstPraticien">PRATICIEN : </label>
				<select id="lstPraticien" name="lstPraticien" >
					<?php
						foreach($praticiens as $praticien){
							$selected = ($praticien['num'] == $compteRendu['numPraticien']) ? " selected='selected'" : "";
							echo "<option value='".$praticien['num']."'".$selected.">".$praticien['nom']." ".$praticien['prenom']."</option>";
						}
					?>
				</select>
			</p>
			<p>
				<label for="lstRemplacant">REMPLACANT : </label>
				<select id="lstRemplacant" name="lstRemplacant" >
					<option value="">-- Aucun --</option>
					<?php
						foreach($praticiens as $praticien){
							$selected = ($praticien['num'] == $compteRendu['numRemplacant']) ? " selected='selected'" : "";
							echo "<option value='".$praticien['num']."'".$selected.">".$praticien['nom']." ".$praticien['prenom']."</option>";
						}
					?>
				</select>
			</p>
			<p>
				<label for="lstMotif">MOTIF : </label>
				<select id="lstMotif" name="lstMotif" >
					<?php
						foreach($motifs as $motif){
							$selected = ($motif['code'] == $compteRendu['motif']) ? " selected='selected'" : "";
							echo "<option value='".$motif['code']."'".$selected.">".$motif['libelle']."</option>";
						}
					?>
				</select>
				<input type="text" size="30" name="txtAutreMotif" value="<?php echo $compteRendu['autreMotif']; ?>" />
			</p>
			<p>
				<label for="txtBilan" ><h3> Bilan </h3></label>
				<textarea rows="5" cols="50" id="txtBilan" name="txtBilan"><?php echo $compteRendu['bilan']; ?></textarea>
			</p>
			<p>
				<label class="titre" ><h3> Eléments présentés </h3></label>
				<label for="chkProduitPresente1">COCHEZ LA CASE : </label>
				<input type="checkbox" name="chkProduitPresente1" id="chkProduitPresente1"/>
				<label for="lstProduit1">CHOISIR PRODUIT 1 : </label>
				<select id="lstProduit1" name="lstProduit1" >
					<?php
						foreach($medicaments as $medicament){
							echo "<option value='".$medicament['depotlegal']."'>".$medicament['nom']."</option>";
						}
					?>
				</select>
				</br></br>
				<label for="chkProduitPresente2">COCHEZ LA CASE : </label>
				<input type="checkbox" name="chkProduitPresente2" id="chkProduitPresente2"/>
				<label for="lstProduit2">CHOISIR PRODUIT 2 : </label>
				<select id="lstProduit2" name="lstProduit2" >
					<?php
						foreach($medicaments as $medicament){
							echo "<option value='".$medicament['depotlegal']."'>".$medicament['nom']."</option>";
						}
					?>
				</select>
				</br></br>
				<label for="chkDoc">DOCUMENTATION OFFERTE : </label>
				<input type="checkbox" name="chkDoc" id="chkDoc" <?php echo ($compteRendu['documentation'] == 1) ? "checked='checked'" : ""; ?>/>
			</p>
			<p>
				<label class="titre"><h3>Echantillons</h3></label>
				<div class="titre" id="lignes">
					<?php
						for ($i=1; $i<=10; $i=$i+1)
						{	
							if ($i % 2 != 0)
							{ 
					?>
						<p>
					<?php
						}
					?>						
						<label for="lstEchantillon[]">PRODUIT <?php echo $i; ?> : </label>
						<select id="lstEchantillon[]" name="lstEchantillon[]" >
							<option value="">-- Choisir --</option>
							<?php
								foreach($medicaments as $medicament){
									echo "<option value='".$medicament['depotlegal']."'>".$medicament['nom']."</option>";
								}
							?>
						</select>
						<input type="text" name="txtQte[]" size="2" value="" />
					<?php
		
						if ($i % 2 == 0)
						{  
					?>
							<br>
							</p>
					<?php
						}
					}
					?>
			
				</div>
			</p>
			<p>
				<label for="txtDateSaisie">DATE SAISIE : </label>
				<input type="text" size="10" id="txtDateSaisie" name="txtDateSaisie" value="<?php echo $compteRendu['dateSaisie']; ?>" />
			</p>
			<p>
				<label for="chkSaisie">SAISIE DEFINITIVE : </label>
				<input id="chkSaisie" name="chkSaisie" type="checkbox" <?php echo ($compteRendu['saisieDefinitive'] == 1) ? "checked='checked'" : ""; ?> />
			</p>
			<p>
				<input type="submit" value="Valider"></input>			
				<input type="reset" value="Annuler"></input>
			</p>
	</form>
</div>
