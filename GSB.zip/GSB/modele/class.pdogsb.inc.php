<?php
/** 
 * Classe d'accès aux données. 
 * Utilise les services de la classe PDO pour l'application GSB
 * @author Cheri Bibi - @version 1.0
 */
class PdoGsb{   		
	private static $serveur=DB_HOST;
	private static $bdd=DB_NAME;   		
	private static $user=DB_LOGIN;    		
	private static $mdp=DB_MDP;		
	private static $monPdo;
	private static $monPdoGsb=null;

	private function __construct(){
		PdoGsb::$monPdo = new PDO(PdoGsb::$serveur.';'.PdoGsb::$bdd, PdoGsb::$user, PdoGsb::$mdp); 
		PdoGsb::$monPdo->query("SET CHARACTER SET utf8");
		PdoGsb::$monPdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	public function _destruct(){
		PdoGsb::$monPdo = null;
	}
	public static function getPdoGsb(){
		if(PdoGsb::$monPdoGsb==null){
			PdoGsb::$monPdoGsb= new PdoGsb();
		}
		return PdoGsb::$monPdoGsb;  
	}

/* ---- TRANSACTIONS ---- */
	public function demarreTransaction(){ PdoGsb::$monPdo->beginTransaction(); }
	public function valideTransaction(){ PdoGsb::$monPdo->commit(); }
	public function annuleTransaction(){ PdoGsb::$monPdo->rollback(); }

/* ---- UTILISATEURS ---- */
	public function getIdCollaborateur($login, $mdp){
		$req = "select COLLABORATEUR.COL_MATRICULE as matricule from COLLABORATEUR 
		where COLLABORATEUR.COL_LOGIN= :login and COLLABORATEUR.COL_MDP= :mdp";
		$idJeuRes = PdoGsb::$monPdo->prepare($req); 
		$idJeuRes->execute(array(':login'=>$login,':mdp'=>$mdp));			
		return $idJeuRes->fetch();
	}

	public function estResponsable($matricule){
		$req = "select count(*) as nbResponsable from COLLABORATEUR inner join RESPONSABLE 
		on COLLABORATEUR.COL_MATRICULE = RESPONSABLE.RES_MATRICULE 
		where COLLABORATEUR.COL_MATRICULE = :matricule";
		$idJeuRes = PdoGsb::$monPdo->prepare($req); 
		$idJeuRes->execute(array(':matricule'=>$matricule));			
		$ligne = $idJeuRes->fetch();
		return ($ligne['nbResponsable'] == 1);
	}

	public function estDelegue($matricule){
		$req = "select count(*) as nbDelegue from COLLABORATEUR inner join DELEGUE_REGIONAL 
		on COLLABORATEUR.COL_MATRICULE = DELEGUE_REGIONAL.DEL_MATRICULE 
		where COLLABORATEUR.COL_MATRICULE = :matricule";
		$idJeuRes = PdoGsb::$monPdo->prepare($req); 
		$idJeuRes->execute(array(':matricule'=>$matricule));			
		$ligne = $idJeuRes->fetch();
		return ($ligne['nbDelegue'] == 1);
	}

	public function getInfosResponsable($matricule){
		$req = "select COL_NOM as nom, COL_PRENOM as prenom from COLLABORATEUR 
		where COL_MATRICULE = :matricule";
		$idJeuRes = PdoGsb::$monPdo->prepare($req); 
		$idJeuRes->execute(array(':matricule'=>$matricule));
		return $idJeuRes->fetch();
	}

	public function getInfosDelegue($matricule){
		$req = "select COL_NOM as nom, COL_PRENOM as prenom from COLLABORATEUR 
		where COL_MATRICULE = :matricule";
		$idJeuRes = PdoGsb::$monPdo->prepare($req); 
		$idJeuRes->execute(array(':matricule'=>$matricule));
		return $idJeuRes->fetch();
	}

	public function getInfosCollaborateur($matricule){
		$req = "select COL_NOM as nom, COL_PRENOM as prenom from COLLABORATEUR 
		where COL_MATRICULE = :matricule";
		$idJeuRes = PdoGsb::$monPdo->prepare($req); 
		$idJeuRes->execute(array(':matricule'=>$matricule));
		return $idJeuRes->fetch();
	}

	function getLesResponsables() {
		$req = "select c.COL_MATRICULE as matricule, c.COL_NOM as nom, c.COL_PRENOM as prenom 
		from COLLABORATEUR c inner join RESPONSABLE r on c.COL_MATRICULE = r.RES_MATRICULE 
		order by c.COL_NOM";
		$idJeuRes = PdoGsb::$monPdo->prepare($req);
		$idJeuRes->execute();
		return $idJeuRes->fetchAll();
	}

	function getLesDelegues() {
		$req = "select c.COL_MATRICULE as matricule, c.COL_NOM as nom, c.COL_PRENOM as prenom 
		from COLLABORATEUR c inner join DELEGUE_REGIONAL d on c.COL_MATRICULE = d.DEL_MATRICULE 
		order by c.COL_NOM";
		$idJeuRes = PdoGsb::$monPdo->prepare($req);
		$idJeuRes->execute();
		return $idJeuRes->fetchAll();
	}

	function getLesVisiteurs() {
		$req = "select COL_MATRICULE as matricule, COL_NOM as nom, COL_PRENOM as prenom 
		from COLLABORATEUR 
		where COL_MATRICULE not in (select RES_MATRICULE from RESPONSABLE) 
		and COL_MATRICULE not in (select DEL_MATRICULE from DELEGUE_REGIONAL) 
		order by COL_NOM";
		$idJeuRes = PdoGsb::$monPdo->prepare($req);
		$idJeuRes->execute();
		return $idJeuRes->fetchAll();
	}

/* ---- MEDICAMENTS ---- */
	public function getLesMedicaments() {
		$req = "select MED_DEPOTLEGAL as depotlegal, MED_NOMCOMMERCIAL as nom 
		from medicament order by MED_NOMCOMMERCIAL";
		$idJeuRes = PdoGsb::$monPdo->prepare($req);
		$idJeuRes->execute();
		return $idJeuRes->fetchAll();
	}

	public function getUnMedicament($depotlegal) {
		$req = "select m.MED_DEPOTLEGAL as depotlegal, m.MED_NOMCOMMERCIAL as nomcommercial, 
		f.FAM_LIBELLE as famille, m.MED_COMPOSITION as composition, 
		m.MED_EFFETS as effets, m.MED_CONTREINDIC as contreindic 
		from medicament m inner join famille f on m.FAM_CODE = f.FAM_CODE 
		where m.MED_DEPOTLEGAL = :depotlegal";
		$idJeuRes = PdoGsb::$monPdo->prepare($req);
		$idJeuRes->execute(array(':depotlegal'=>$depotlegal));
		return $idJeuRes->fetch();
	}

/* ---- PRATICIENS ---- */
	public function getLesPraticiens() {
		$req = "select PRA_NUM as num, PRA_NOM as nom, PRA_PRENOM as prenom 
		from praticien order by PRA_NOM";
		$idJeuRes = PdoGsb::$monPdo->prepare($req);
		$idJeuRes->execute();
		return $idJeuRes->fetchAll();
	}

	public function getUnPraticien($num) {
		$req = "select p.PRA_NUM as num, p.PRA_NOM as nom, p.PRA_PRENOM as prenom, 
		p.PRA_ADRESSE as adresse, p.PRA_CP as cp, p.PRA_VILLE as ville, 
		p.PRA_COEFNOTORIETE as notoriete, p.PRA_COEFCONFIANCE as confiance, 
		t.TYP_LIBELLE as type, t.TYP_LIEU as lieu 
		from praticien p inner join type_praticien t on p.TYP_CODE = t.TYP_CODE 
		where p.PRA_NUM = :num";
		$idJeuRes = PdoGsb::$monPdo->prepare($req);
		$idJeuRes->execute(array(':num'=>$num));
		return $idJeuRes->fetch();
	}

	public function getLesTypesPraticien() {
		$req = "select TYP_CODE as code, TYP_LIBELLE as libelle 
		from type_praticien order by TYP_LIBELLE";
		$idJeuRes = PdoGsb::$monPdo->prepare($req);
		$idJeuRes->execute();
		return $idJeuRes->fetchAll();
	}

	public function ajouterPraticien($num, $nom, $prenom, $adresse, $cp, $ville, $notoriete, $confiance, $type) {
		$req = "insert into praticien 
		(PRA_NUM, PRA_NOM, PRA_PRENOM, PRA_ADRESSE, PRA_CP, PRA_VILLE, PRA_COEFNOTORIETE, PRA_COEFCONFIANCE, TYP_CODE) 
		values (:num, :nom, :prenom, :adresse, :cp, :ville, :notoriete, :confiance, :type)";
		$idJeuRes = PdoGsb::$monPdo->prepare($req);
		$idJeuRes->execute(array(
			':num'=>$num,':nom'=>$nom,':prenom'=>$prenom,':adresse'=>$adresse,
			':cp'=>$cp,':ville'=>$ville,':notoriete'=>$notoriete,':confiance'=>$confiance,':type'=>$type
		));
	}

/* ---- COMPTES-RENDUS ---- */
	public function getLesMotifs() {
		$req = "select MOT_CODE as code, MOT_LIBELLE as libelle from motif";
		$idJeuRes = PdoGsb::$monPdo->prepare($req);
		$idJeuRes->execute();
		return $idJeuRes->fetchAll();
	}

	public function getLesCompteRenduDuVisiteur($matricule) {
		$req = "select r.RAP_NUM as num, r.RAP_DATE_VISITE as dateVisite, 
		p.PRA_NOM as nomPraticien, p.PRA_PRENOM as prenomPraticien 
		from rapport_visite r inner join praticien p on r.PRA_NUM = p.PRA_NUM 
		where r.COL_MATRICULE = :matricule 
		order by r.RAP_DATE_VISITE desc";
		$idJeuRes = PdoGsb::$monPdo->prepare($req);
		$idJeuRes->execute(array(':matricule'=>$matricule));
		return $idJeuRes->fetchAll();
	}

	public function getUnCompteRendu($numRapport) {
		$req = "select RAP_NUM as num, COL_MATRICULE as matricule, 
		PRA_NUM as numPraticien, PRA_NUM_REMPLACANT as numRemplacant, 
		RAP_DATE_VISITE as dateVisite, RAP_DATE_SAISIE as dateSaisie, 
		RAP_BILAN as bilan, RAP_MOTIF_AUTRE as autreMotif, MOT_CODE as motif, 
		RAP_DOCUMENTATION as documentation, RAP_SAISIEDEFINITIVE as saisieDefinitive 
		from rapport_visite where RAP_NUM = :numRapport";
		$idJeuRes = PdoGsb::$monPdo->prepare($req);
		$idJeuRes->execute(array(':numRapport'=>$numRapport));
		return $idJeuRes->fetch();
	}

	public function ajouterCompteRendu($matricule, $numRapport, $numPraticien, $numRemplacant, $dateVisite, $dateSaisie, $bilan, $autreMotif, $motif, $documentation, $saisieDefinitive) {
		$req = "insert into rapport_visite 
		(COL_MATRICULE, RAP_NUM, PRA_NUM, PRA_NUM_REMPLACANT, RAP_DATE_VISITE, RAP_DATE_SAISIE, 
		RAP_BILAN, RAP_MOTIF_AUTRE, MOT_CODE, RAP_DOCUMENTATION, RAP_SAISIEDEFINITIVE) 
		values (:matricule, :numRapport, :numPraticien, :numRemplacant, :dateVisite, :dateSaisie, 
		:bilan, :autreMotif, :motif, :documentation, :saisieDefinitive)";
		$idJeuRes = PdoGsb::$monPdo->prepare($req);
		$idJeuRes->execute(array(
			':matricule'=>$matricule,':numRapport'=>$numRapport,
			':numPraticien'=>$numPraticien,':numRemplacant'=>$numRemplacant,
			':dateVisite'=>$dateVisite,':dateSaisie'=>$dateSaisie,
			':bilan'=>$bilan,':autreMotif'=>$autreMotif,':motif'=>$motif,
			':documentation'=>$documentation,':saisieDefinitive'=>$saisieDefinitive
		));
	}

	public function ajouterProduitPresente($depotlegal, $matricule, $numRapport) {
		$req = "insert into presenter (MED_DEPOTLEGAL, COL_MATRICULE, RAP_NUM) 
		values (:depotlegal, :matricule, :numRapport)";
		$idJeuRes = PdoGsb::$monPdo->prepare($req);
		$idJeuRes->execute(array(':depotlegal'=>$depotlegal,':matricule'=>$matricule,':numRapport'=>$numRapport));
	}

	public function ajouterEchantillon($matricule, $numRapport, $depotlegal, $qte) {
		$req = "insert into offrir (COL_MATRICULE, RAP_NUM, MED_DEPOTLEGAL, OFF_QTE) 
		values (:matricule, :numRapport, :depotlegal, :qte)";
		$idJeuRes = PdoGsb::$monPdo->prepare($req);
		$idJeuRes->execute(array(':matricule'=>$matricule,':numRapport'=>$numRapport,':depotlegal'=>$depotlegal,':qte'=>$qte));
	}

	public function modifierCompteRendu($numRapport, $numPraticien, $numRemplacant, $dateVisite, $dateSaisie, $bilan, $autreMotif, $motif, $documentation, $saisieDefinitive) {
		$req = "update rapport_visite set 
		PRA_NUM=:numPraticien, PRA_NUM_REMPLACANT=:numRemplacant, 
		RAP_DATE_VISITE=:dateVisite, RAP_DATE_SAISIE=:dateSaisie, 
		RAP_BILAN=:bilan, RAP_MOTIF_AUTRE=:autreMotif, MOT_CODE=:motif, 
		RAP_DOCUMENTATION=:documentation, RAP_SAISIEDEFINITIVE=:saisieDefinitive 
		where RAP_NUM=:numRapport";
		$idJeuRes = PdoGsb::$monPdo->prepare($req);
		$idJeuRes->execute(array(
			':numPraticien'=>$numPraticien,':numRemplacant'=>$numRemplacant,
			':dateVisite'=>$dateVisite,':dateSaisie'=>$dateSaisie,
			':bilan'=>$bilan,':autreMotif'=>$autreMotif,':motif'=>$motif,
			':documentation'=>$documentation,':saisieDefinitive'=>$saisieDefinitive,
			':numRapport'=>$numRapport
		));
	}

	public function getCompteRenduParPeriode($dateDebut, $dateFin, $matricule=null) {
		if ($matricule) {
			$req = "select r.RAP_NUM as num, r.RAP_DATE_VISITE as dateVisite, 
			c.COL_NOM as nomVisiteur, c.COL_PRENOM as prenomVisiteur,
			p.PRA_NOM as nomPraticien, p.PRA_PRENOM as prenomPraticien, r.RAP_BILAN as bilan 
			from rapport_visite r 
			inner join collaborateur c on r.COL_MATRICULE=c.COL_MATRICULE 
			inner join praticien p on r.PRA_NUM=p.PRA_NUM 
			where r.COL_MATRICULE=:matricule and r.RAP_DATE_VISITE between :dateDebut and :dateFin 
			order by r.RAP_DATE_VISITE desc";
			$idJeuRes = PdoGsb::$monPdo->prepare($req);
			$idJeuRes->execute(array(':matricule'=>$matricule,':dateDebut'=>$dateDebut,':dateFin'=>$dateFin));
		} else {
			$req = "select r.RAP_NUM as num, r.RAP_DATE_VISITE as dateVisite, 
			c.COL_NOM as nomVisiteur, c.COL_PRENOM as prenomVisiteur,
			p.PRA_NOM as nomPraticien, p.PRA_PRENOM as prenomPraticien, r.RAP_BILAN as bilan 
			from rapport_visite r 
			inner join collaborateur c on r.COL_MATRICULE=c.COL_MATRICULE 
			inner join praticien p on r.PRA_NUM=p.PRA_NUM 
			where r.RAP_DATE_VISITE between :dateDebut and :dateFin 
			order by r.RAP_DATE_VISITE desc";
			$idJeuRes = PdoGsb::$monPdo->prepare($req);
			$idJeuRes->execute(array(':dateDebut'=>$dateDebut,':dateFin'=>$dateFin));
		}
		return $idJeuRes->fetchAll();
	}

	public function getCompteRenduParRegion($codeRegion) {
		$req = "select r.RAP_NUM as num, r.RAP_DATE_VISITE as dateVisite, 
		c.COL_NOM as nomVisiteur, c.COL_PRENOM as prenomVisiteur,
		p.PRA_NOM as nomPraticien, p.PRA_PRENOM as prenomPraticien, r.RAP_BILAN as bilan 
		from rapport_visite r 
		inner join collaborateur c on r.COL_MATRICULE=c.COL_MATRICULE 
		inner join praticien p on r.PRA_NUM=p.PRA_NUM 
		inner join travailler t on c.COL_MATRICULE=t.COL_MATRICULE 
		where t.REG_CODE=:codeRegion and t.DATE_FIN is null 
		order by r.RAP_DATE_VISITE desc";
		$idJeuRes = PdoGsb::$monPdo->prepare($req);
		$idJeuRes->execute(array(':codeRegion'=>$codeRegion));
		return $idJeuRes->fetchAll();
	}

	public function getRegionDuDelegue($matricule) {
		$req = "select REG_CODE as code from DELEGUE_REGIONAL where DEL_MATRICULE=:matricule";
		$idJeuRes = PdoGsb::$monPdo->prepare($req);
		$idJeuRes->execute(array(':matricule'=>$matricule));
		return $idJeuRes->fetch();
	}

	public function getLesRegions() {
		$req = "select REG_CODE as code, REG_NOM as nom from region order by REG_NOM";
		$idJeuRes = PdoGsb::$monPdo->prepare($req);
		$idJeuRes->execute();
		return $idJeuRes->fetchAll();
	}

	public function getCompteRenduParSecteur($codeSecteur) {
		$req = "select r.RAP_NUM as num, r.RAP_DATE_VISITE as dateVisite, 
		c.COL_NOM as nomVisiteur, c.COL_PRENOM as prenomVisiteur,
		p.PRA_NOM as nomPraticien, p.PRA_PRENOM as prenomPraticien, 
		r.RAP_BILAN as bilan, reg.REG_NOM as nomRegion 
		from rapport_visite r 
		inner join collaborateur c on r.COL_MATRICULE=c.COL_MATRICULE 
		inner join praticien p on r.PRA_NUM=p.PRA_NUM 
		inner join travailler t on c.COL_MATRICULE=t.COL_MATRICULE 
		inner join region reg on t.REG_CODE=reg.REG_CODE 
		where reg.SEC_CODE=:codeSecteur and t.DATE_FIN is null 
		order by r.RAP_DATE_VISITE desc";
		$idJeuRes = PdoGsb::$monPdo->prepare($req);
		$idJeuRes->execute(array(':codeSecteur'=>$codeSecteur));
		return $idJeuRes->fetchAll();
	}

	public function getSecteurDuResponsable($matricule) {
		$req = "select SEC_CODE as code from RESPONSABLE where RES_MATRICULE=:matricule";
		$idJeuRes = PdoGsb::$monPdo->prepare($req);
		$idJeuRes->execute(array(':matricule'=>$matricule));
		return $idJeuRes->fetch();
	}

	public function getCompteRenduParVisiteur($matriculeVisiteur) {
		$req = "select r.RAP_NUM as num, r.RAP_DATE_VISITE as dateVisite, 
		p.PRA_NOM as nomPraticien, p.PRA_PRENOM as prenomPraticien, r.RAP_BILAN as bilan 
		from rapport_visite r inner join praticien p on r.PRA_NUM=p.PRA_NUM 
		where r.COL_MATRICULE=:matricule order by r.RAP_DATE_VISITE desc";
		$idJeuRes = PdoGsb::$monPdo->prepare($req);
		$idJeuRes->execute(array(':matricule'=>$matriculeVisiteur));
		return $idJeuRes->fetchAll();
	}
}	
?>
